create view local_cache
            (pageoffs, relfilenode, reltablespace, reldatabase, relforknumber, relblocknumber, accesscount) as
SELECT pageoffs,
       relfilenode,
       reltablespace,
       reldatabase,
       relforknumber,
       relblocknumber,
       accesscount
FROM neon.local_cache_pages() p(pageoffs bigint, relfilenode oid, reltablespace oid, reldatabase oid,
                                relforknumber smallint, relblocknumber bigint, accesscount integer);

alter table local_cache
    owner to cloud_admin;

